# INFO6205_Life
Repository for the Life project
